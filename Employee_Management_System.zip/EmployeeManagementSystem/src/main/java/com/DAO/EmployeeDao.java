package com.DAO;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.Entity.Employee;

public class EmployeeDao {


	public Connection getConnection() {
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");  
			con=DriverManager.getConnection(  "jdbc:mysql://localhost:3306/Project","root","monisha20");  
			//here sonoo is database name, root is username and password  
//			Statement stmt=con.createStatement();  

		}catch(Exception e){ 
			System.out.println(e);
		} 
		return con;

	}



	public List<Employee> listUser() {
		List<Employee> employees=new ArrayList<>();
		try {
			Connection con=getConnection();
			PreparedStatement preparedStatement = con.prepareStatement("select * from employees"); 
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("ID");
				String name = rs.getString("NAME");
				int salary = rs.getInt("SALARY");
				String empId = rs.getString("EMPL_ID");
				String designation = rs.getString("DESIGNATION");	 

				Employee emp=new Employee();
				emp.setId(id);
				emp.setName(name);
				emp.setDesignation(designation);
				emp.setSalary(salary);
				emp.setEmplId(empId);


				employees.add(emp);
			}
		}catch(SQLException e) {
			printSQLException(e);
		}
		return employees;

	}
	private void printSQLException(SQLException ex) {
		for (Throwable e: ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}


	//	"INSERT INTO users" + "  (name, email, country) VALUES "
	//	+ " (?, ?, ?);";
	public void createUser(Employee emp) {
		try {
			Connection con=getConnection();
			PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO employees" + " (NAME,SALARY,EMPL_ID,DESIGNATION) VALUES " + "(?,?,?,?);"); 
			preparedStatement.setString(1,emp.getName());
			preparedStatement.setInt(2,emp.getSalary());
			preparedStatement.setString(3,emp.getEmplId());
			preparedStatement.setString(4,emp.getDesignation());
			preparedStatement.execute();

		}catch(SQLException e) {
			printSQLException(e);
		}
	}



	public void deleteEmployee(int id) {
		try {
			Connection con=getConnection();
			PreparedStatement preparedStatement = con.prepareStatement("delete from employees where id=?; ");
			preparedStatement.setInt(1,id);
			preparedStatement.execute();
		}catch(SQLException e) {
			printSQLException(e);
		}
	}



	public Employee editUser(int id) {
		Employee emp=null;
		try {
			Connection con=getConnection();
			PreparedStatement preparedStatement = con.prepareStatement("select * from employees where id=? ");
			preparedStatement.setInt(1, id);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next()) {
				int id1 = rs.getInt("ID");
				String name = rs.getString("NAME");
				int salary = rs.getInt("SALARY");
				String empId = rs.getString("EMPL_ID");
				String designation = rs.getString("DESIGNATION");
				 emp=new Employee();
				emp.setId(id1);
				emp.setName(name);
				emp.setSalary(salary);
				emp.setEmplId(empId);
				emp.setDesignation(designation);
				

			}
		}catch(SQLException e) {
			printSQLException(e);
		}
		return emp;
	}



	public void updateUser(Employee emp) {
		try {
			Connection con=getConnection();
			PreparedStatement preparedStatement = con.prepareStatement("update employees set NAME=?,SALARY=?,EMPL_ID=?,DESIGNATION=? where id=?;"); 
			preparedStatement.setString(1,emp.getName());
			preparedStatement.setInt(2,emp.getSalary());
			preparedStatement.setString(3,emp.getEmplId());
			preparedStatement.setString(4,emp.getDesignation());
			preparedStatement.setInt(5,emp.getId());

			preparedStatement.executeUpdate();

		}catch(SQLException e) {
			printSQLException(e);
		}
		
	}

}